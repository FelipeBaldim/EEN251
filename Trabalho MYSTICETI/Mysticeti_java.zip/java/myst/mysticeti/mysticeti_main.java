package myst.mysticeti;

import android.app.ActionBar;
import android.app.AlertDialog;
import android.bluetooth.BluetoothAdapter;
import android.bluetooth.BluetoothDevice;
import android.bluetooth.BluetoothSocket;
import android.content.DialogInterface;
import android.content.Intent;
import android.content.res.Resources;
import android.media.MediaPlayer;
import android.os.Bundle;
import android.os.Handler;
import android.os.Message;
import android.support.design.widget.FloatingActionButton;
import android.support.design.widget.Snackbar;
import android.util.DisplayMetrics;
import android.util.TypedValue;
import android.view.View;
import android.support.design.widget.NavigationView;
import android.support.v4.view.GravityCompat;
import android.support.v4.widget.DrawerLayout;
import android.support.v7.app.ActionBarDrawerToggle;
import android.support.v7.app.AppCompatActivity;
import android.support.v7.widget.Toolbar;
import android.view.Menu;
import android.view.MenuItem;
import android.view.ViewGroup;
import android.view.WindowManager;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.RelativeLayout;
import android.widget.TextView;
import android.widget.Toast;

import java.io.DataOutputStream;
import java.io.IOException;
import java.util.Set;
import java.util.UUID;

public class mysticeti_main extends AppCompatActivity
        implements NavigationView.OnNavigationItemSelectedListener {

    RadarView mysticeti_radar = null;
    RelativeLayout rlObjects;
    boolean connected = false;
    Button btnConnect;
    String which,who;
    wrkThread loopThread;
    String data ="";
    boolean reverse = false;
    ImageView found;
    int px =0;
    int py=0;
    double bolay, bolax;
    RelativeLayout.LayoutParams layoutParams;
    DisplayMetrics displayMetrics;
    MediaPlayer mp;
    int grau=0;
    //region Bluetooth
    protected static final UUID MY_UUID = UUID.fromString("00001101-0000-1000-8000-00805F9B34FB"); // valor de UUID para conexão Bluetooth
    BluetoothAdapter bt_adapter; // BluetoothAdapter para funções bluetooth
    BluetoothSocket btsocket; // BluetoothSocket para comunicação entra app e dispositivo
    BluetoothDevice btdevice; // BluetoothDevice (Dispositivo) objeto a ser conectado
    DataOutputStream out; // DataOutputStream para envio dos comandos por Bluetooth
    TextView tvdist;
    //endregion

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_mysticeti_main);
        this.getWindow().getDecorView().setSystemUiVisibility(View.SYSTEM_UI_FLAG_LAYOUT_STABLE
                | View.SYSTEM_UI_FLAG_LAYOUT_HIDE_NAVIGATION
                | View.SYSTEM_UI_FLAG_LAYOUT_FULLSCREEN
                | View.SYSTEM_UI_FLAG_HIDE_NAVIGATION
                | View.SYSTEM_UI_FLAG_FULLSCREEN
                | View.SYSTEM_UI_FLAG_IMMERSIVE_STICKY);
        this.getWindow().setFlags(WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS, WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS);
        Toolbar toolbar = (Toolbar) findViewById(R.id.toolbar);
        setSupportActionBar(toolbar);
        btnConnect = (Button) findViewById(R.id.btnConnect);
        tvdist = (TextView) findViewById(R.id.tvdist);
        found = new ImageView(mysticeti_main.this);
        displayMetrics = getResources().getDisplayMetrics();



        mp = MediaPlayer.create(mysticeti_main.this,R.raw.sonar_sound);
        mp.setLooping(true);




        DrawerLayout drawer = (DrawerLayout) findViewById(R.id.drawer_layout);
        ActionBarDrawerToggle toggle = new ActionBarDrawerToggle(
                this, drawer, toolbar, R.string.navigation_drawer_open, R.string.navigation_drawer_close);
        drawer.setDrawerListener(toggle);
        toggle.syncState();


        NavigationView navigationView = (NavigationView) findViewById(R.id.nav_view);
        navigationView.setNavigationItemSelectedListener(this);


        bt_adapter = BluetoothAdapter.getDefaultAdapter(); //referência o BTadapet ao adaptador do smartphone
        if (!bt_adapter.isEnabled()) {
            bt_adapter.enable(); // habilita o bluetooth do celular
            try {
                while (!bt_adapter.isEnabled()) {
                    Thread.sleep(10);
                }
            } catch (InterruptedException e) {
                e.printStackTrace();
            }
        }
    }


    @Override
    public void onResume() {
        super.onResume();
        this.getWindow().getDecorView().setSystemUiVisibility(View.SYSTEM_UI_FLAG_LAYOUT_STABLE
                | View.SYSTEM_UI_FLAG_LAYOUT_HIDE_NAVIGATION
                | View.SYSTEM_UI_FLAG_LAYOUT_FULLSCREEN
                | View.SYSTEM_UI_FLAG_HIDE_NAVIGATION
                | View.SYSTEM_UI_FLAG_FULLSCREEN
                | View.SYSTEM_UI_FLAG_IMMERSIVE_STICKY);
        this.getWindow().setFlags(WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS, WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS);
    }

    @Override
    public void onBackPressed() {
        DrawerLayout drawer = (DrawerLayout) findViewById(R.id.drawer_layout);
        if (drawer.isDrawerOpen(GravityCompat.START)) {
            drawer.closeDrawer(GravityCompat.START);
        } else {
            super.onBackPressed();
        }
    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        // Inflate the menu; this adds items to the action bar if it is present.
        getMenuInflater().inflate(R.menu.mysticeti_main, menu);
        return true;
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        // Handle action bar item clicks here. The action bar will
        // automatically handle clicks on the Home/Up button, so long
        // as you specify a parent activity in AndroidManifest.xml.
        int id = item.getItemId();

        //noinspection SimplifiableIfStatement
        if (id == R.id.action_settings) {
            return true;
        }

        return super.onOptionsItemSelected(item);
    }

    @SuppressWarnings("StatementWithEmptyBody")
    @Override
    public boolean onNavigationItemSelected(MenuItem item) {
        // Handle navigation view item clicks here.
        int id = item.getItemId();

        if (id == R.id.nav_home) {
            // Handle the camera action
        } else if (id == R.id.nav_mysticeti) {

        }

        DrawerLayout drawer = (DrawerLayout) findViewById(R.id.drawer_layout);
        drawer.closeDrawer(GravityCompat.START);
        return true;
    }

    //region CommunicationThread

    private class wrkThread extends Thread { //classe responsável pelo tratamento dos dados recebidos e comunicação com BT900

        @Override
        public void run() {
            int bytesAvailable = 0;
            try {
                while (!loopThread.isInterrupted()) {
                    bytesAvailable = btsocket.getInputStream().available(); // bytesAvailable recebe os bytes disponíveis no socket
                    if (bytesAvailable > 0) { //verifica se há dados
                        byte[] packetBytes = new byte[bytesAvailable]; // packetBytes recebe os valores lidos
                        btsocket.getInputStream().read(packetBytes); // socket processa os
                        data += new String(packetBytes, 0, bytesAvailable); // formação da String de dados
                        runOnUiThread(new Runnable() {
                            @Override
                            public void run() {
                                try {
                                    if (data != "" && data.contains("\r\n")) { // verifica se String de dados não é vazia e contém byte de fim de envio \n
                                        // if(data.contains("@"))
                                        //   {
                                        // String[] dados = data.split(",");
                                        // for (int i=0; i<dados.length;i++) {
                                        String[] rds = data.split("\r\n");
                                        if(rds[0].length()>0) {
                                            if (((Double.parseDouble(rds[0].split(",")[0])) <= 400) && ((Integer.parseInt(rds[0].split(",")[1])) == 10)) {
                                                tvdist.setText(data.split("\r\n")[0].split(",")[0] + "cm");
                                                if (grau == 360) {
                                                    reverse = true;
                                                }
                                                else if(grau == 0)
                                                {
                                                    reverse = false;
                                                }
                                                if(reverse)
                                                {
                                                    grau--;
                                                }
                                                else {
                                                    grau++;
                                                }
                                                bolay = Math.sin(Math.toRadians(grau)) * (Double.parseDouble(rds[0].split(",")[0]));
                                                bolax = Math.cos(Math.toRadians(grau))  * (Double.parseDouble(rds[0].split(",")[0]));
                                                px = 200+(int) bolax;
                                                py = 200+(int) bolay;
                                                //px = Integer.parseInt(dados[i].substring(5,dados[i].length()-2));
                                                //py = Integer.parseInt(dados[i+1].substring(5,dados[i+1].length()-2));
                                                //   }
                                                //Resources r = getResources();
                                                //float pxx = TypedValue.applyDimension(TypedValue.COMPLEX_UNIT_DIP, px, r.getDisplayMetrics());
                                                //float pyx = TypedValue.applyDimension(TypedValue.COMPLEX_UNIT_DIP,py , r.getDisplayMetrics());
                                                layoutParams.setMargins(dpToPx(px), dpToPx(py), 0, 0);
                                                found.setVisibility(View.VISIBLE);
                                                found.setLayoutParams(layoutParams);

                                                //   }
                                            }
                                        }
                                        data = "";
                                        //endregion
                                    }
                                }
                                catch(Exception ex)
                                {
                                    String k = ex.getMessage();
                                }
                            }
                        });
                    }
                }

            } catch (IOException e) {
                e.printStackTrace();
            }
        }

    }
//endregion

    private Handler bt900_handler = new Handler() {
        @Override
        public void handleMessage(final Message msg) {
            switch (msg.what) {
                //region MSG_CONNECT
                case 0:
                    btdevice = bt_adapter.getRemoteDevice(which); // referencia btdevice ao item selecionado na lista
                    try {
                        btsocket = btdevice.createRfcommSocketToServiceRecord(MY_UUID); // referencia btsocket ao UUID configurado
                    } catch (IOException e) {
                        runOnUiThread(new Runnable() {
                            public void run() {
                                Toast.makeText(getApplicationContext(), "NÃO FOI POSSÍVEL CONECTAR-SE AO DISPOSITIVO", Toast.LENGTH_SHORT).show(); // exibe aviso
                                btnConnect.setEnabled(true); //habilita o botão btnConnect
                            }
                        });
                    }
                    Thread connect = new Thread() {
                        @Override
                        public void run() {
                            try {
                                if (!connected) { // verifica se não está conectado
                                    if (!btsocket.isConnected() && !connected) { // verifica se não foi conectado
                                        btsocket.connect(); // tenta conectar ao btsocket
                                        out = new DataOutputStream(btsocket.getOutputStream()); // referencia out (DataOutputStream) ao socket
                                    }
                                    if (btsocket.isConnected()) { // verifica se o socket está conectado
                                        loopThread = new wrkThread(); // inicializa a Thread de comunicação
                                       loopThread.start(); // inicia a Thread
                                        //out.writeBytes("\r\n\r\n\r\n\r\n"); // envia comando para execução do comando de conexão
                                        runOnUiThread(new Runnable() {
                                            public void run() {
                                                mp.start();
                                                Toast.makeText(getApplicationContext(), "CONECTADO", Toast.LENGTH_SHORT).show(); // exibe aviso
                                                mysticeti_radar = (RadarView) findViewById(R.id.radarView);
                                                mysticeti_radar.setShowCircles(true);
                                                mysticeti_radar.startAnimation();
                                                rlObjects = (RelativeLayout) findViewById(R.id.rlObjects);

                                                found.setImageResource(R.drawable.object_find);
                                                layoutParams = new RelativeLayout.LayoutParams(
                                                        RelativeLayout.LayoutParams.WRAP_CONTENT, RelativeLayout.LayoutParams.WRAP_CONTENT);
                                                displayMetrics = getResources().getDisplayMetrics();
                                                btnConnect.setVisibility(View.INVISIBLE);
                                                mysticeti_radar.setVisibility(View.VISIBLE);
                                                rlObjects.addView(found);
                                            }
                                        });

                                    } else {
                                        runOnUiThread(new Runnable() {
                                            public void run() {
                                                Toast.makeText(getApplicationContext(), "NÃO FOI POSSÍVEL CONECTAR-SE AO DISPOSITIVO", Toast.LENGTH_SHORT).show(); // exibe aviso
                                                btnConnect.setEnabled(true);
                                            }
                                        });
                                    }
                                }
                            } catch (IOException e) {
                                runOnUiThread(new Runnable() {
                                    public void run() {
                                        Toast.makeText(getApplicationContext(), "FALHA NA CONEXÃO", Toast.LENGTH_SHORT).show(); // exibe aviso
                                        btnConnect.setEnabled(true); //habilita btnConnect
                                        onResume();
                                      //  pbConnect.setVisibility(View.INVISIBLE); // alteração na vibilidade do pbConnect
                                       // tvConnect.setText("LIETOR BT900 DESCONECTADO"); // alteração no texto do tvConnect
                                        //anim_handler.sendEmptyMessage(ANIM_CONNECT_OFF);
                                    }
                                });
                             //   connecting = false; // altera flag de status de conexão
                            }
                            runOnUiThread(new Runnable() {
                                public void run() {
                                    onResume();
                                }
                            });
                        }
                    };
                    connect.start();
                    break;
                //endregion

            }
        }
    };

    public void Connect(View v)
    {
        if (!connected) {
            Set<BluetoothDevice> pairedDevices = bt_adapter.getBondedDevices(); // verifica valores dos dispositivos pareados com o smartphone
            int index = 0; // inicializa variável para contagem de dispositivos válidos
            for (BluetoothDevice bt : pairedDevices) {  // loop para verificação dos dispositivos
                    index++; // incremento da variável auxiliar
            }
            final CharSequence actions[] = new CharSequence[index];// array para listagem dos dispositivos pareados
            for (BluetoothDevice bt : pairedDevices) { // loop para referenciação
                    actions[index - 1] = "ID: " + bt.getName() + "\nMAC: " + bt.getAddress(); // referencia opções com os dispositivos válidos
                    index--; // decremento da vari´vel auxiliar
            }
            AlertDialog.Builder builder = new AlertDialog.Builder(mysticeti_main.this); // cria AlertDialog
            builder.setTitle("ESCOLHA O DIPOSITIVO"); // titulo do AlertDialog
            builder.setNegativeButton("CANCELAR", new DialogInterface.OnClickListener() { // botão negativo do AlertDialog
                @Override
                public void onClick(DialogInterface dialog, int which) {
                    // simplesmente não realiza nenhum operação
                }
            });
            builder.setPositiveButton("ADICIONAR NOVO", new DialogInterface.OnClickListener() { // botão positivo do AlertDialog
                @Override
                public void onClick(DialogInterface dialog, int which) {
                    Intent settingsIntent = new Intent(android.provider.Settings.ACTION_BLUETOOTH_SETTINGS); // configura ação para abertura das conigurações de BT
                    startActivity(settingsIntent); // exibe a tela de configurações de bluetooth
                }
            });
            builder.setItems(actions, new DialogInterface.OnClickListener() { // relaciona os itens (dispositivos válidos) as opções do AlertDialog
                @Override
                public void onClick(DialogInterface dialog, int i) {
                    // the user clicked on colors[which]
                    btnConnect.setEnabled(false); // desabilita o btn Connect
                    who = actions[i].toString().split("\n")[0].substring(4); // referencia a variável do nome do dispositivo
                    which = actions[i].toString().split("\n")[1].substring(5); // referencia a variável do MAC do dispositivo
                    bt900_handler.sendEmptyMessage(0);
                   // anim_handler.sendEmptyMessage(ANIM_CONNECT_ON); // executa alteração visual
                }
            });
            builder.show(); // exibe o AlertDialog
        } else {

        }

    }
    public int pxToDp(int px) {
        DisplayMetrics displayMetrics = getResources().getDisplayMetrics();
        int dp = Math.round(px / (displayMetrics.xdpi / DisplayMetrics.DENSITY_DEFAULT));
        return dp;
    }

    public int dpToPx(int dp) {
        DisplayMetrics displayMetrics = getResources().getDisplayMetrics();
        int px = Math.round(dp * (displayMetrics.xdpi / DisplayMetrics.DENSITY_DEFAULT));
        return px;
    }

}
