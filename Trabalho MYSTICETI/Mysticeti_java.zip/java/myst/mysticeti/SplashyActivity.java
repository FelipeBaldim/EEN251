package myst.mysticeti;

import android.app.Activity;
import android.content.Intent;
import android.media.MediaPlayer;
import android.os.AsyncTask;
import android.os.Bundle;
import android.view.View;
import android.view.WindowManager;
import android.view.animation.Animation;
import android.view.animation.AnimationUtils;
import android.widget.ImageView;
import android.widget.TextView;

/**
 * Created by r.peres on 28/10/2016.
 */
public class SplashyActivity extends Activity {
    private static final int SPLASH_SHOW_TIME = 4000;
    MediaPlayer mp;
    ImageView ivLoading, ivLoading2;
    TextView tvLoading;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.content_loading);
        this.getWindow().getDecorView().setSystemUiVisibility(View.SYSTEM_UI_FLAG_LAYOUT_STABLE
                | View.SYSTEM_UI_FLAG_LAYOUT_HIDE_NAVIGATION
                | View.SYSTEM_UI_FLAG_LAYOUT_FULLSCREEN
                | View.SYSTEM_UI_FLAG_HIDE_NAVIGATION
                | View.SYSTEM_UI_FLAG_FULLSCREEN
                | View.SYSTEM_UI_FLAG_IMMERSIVE_STICKY);
        this.getWindow().setFlags(WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS, WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS);
        ivLoading = (ImageView) findViewById(R.id.ivLoading);
        ivLoading2 = (ImageView) findViewById(R.id.ivLoading2);
        tvLoading = (TextView) findViewById(R.id.tvLoading);
        new BackgroundSplashTask().execute();
    }

    private class BackgroundSplashTask extends AsyncTask<Void, Void, Void> {

        @Override
        protected void onPreExecute() {
            super.onPreExecute();
            Animation anim = AnimationUtils.loadAnimation(SplashyActivity.this, R.anim.animation_clockwise);
            ivLoading.setAnimation(anim);
            anim.setAnimationListener(new Animation.AnimationListener() {
                @Override
                public void onAnimationStart(Animation animation) {

                }

                @Override
                public void onAnimationEnd(Animation animation) {
                    Animation anim2 = AnimationUtils.loadAnimation(SplashyActivity.this, R.anim.animation_fade);
                    ivLoading2.setAnimation(anim2);
                    tvLoading.setAnimation(anim2);
                    anim2.start();
                    ivLoading2.setVisibility(View.VISIBLE);
                    tvLoading.setVisibility(View.VISIBLE);
                }

                @Override
                public void onAnimationRepeat(Animation animation) {

                }
            });
            anim.start();
        }

        @Override
        protected Void doInBackground(Void... arg0) {
            try {
                mp = MediaPlayer.create(SplashyActivity.this, R.raw.whale_sound);
                mp.start();
                Thread.sleep(SPLASH_SHOW_TIME);
            } catch (InterruptedException e) {
                e.printStackTrace();
            }
            return null;
        }

        @Override
        protected void onPostExecute(Void result) {
            super.onPostExecute(result);
            Intent i = new Intent(SplashyActivity.this, mysticeti_main.class);
            mp.stop();
            startActivity(i);
            finish();
        }

    }
}
